package fr.umlv.unitex.common.frames.manager;

/**
 * 
 * @author mdamis
 *
 */
public interface FrameManager {}
